/**
 * Created by gaoguoqing on 2019/11/29.
 *
 */
const BASE_URL = '/login'
module.exports = {
    //菜单数据mock
    [BASE_URL + '/sys/user/test']: './test/test.js',
}

