/**
 * Created by gaoguoqing on 2019/11/29.
 *
 */
module.exports = {
    'success': true,
    'errorCode': '0',
    'data': 'mock测试11'
}
