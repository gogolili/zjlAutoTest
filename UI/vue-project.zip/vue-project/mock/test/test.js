/**
 * Created by gaoguoqing on 2019/6/28.
 *
 */
module.exports = {
    'success': true,
    'errorCode': '0',
    'data': 'mock测试'
}

let a = {
    'requestId': '5d68daaa-2cac-4a6c-9e28-03c5414210b1',
    'success': true,
    'errorCode': '0',
    'total': 0,
    'data': [
        {
            'addressAndPhone': '百望股份',
            'bankAndAccount': '华夏银行股份有限公司长春分行 13750000000762961',
            'bank': '',
            'bankAccount': '',
            'city': '长春市',
            'county': '市辖区',
            'fixedPhone': '',
            'frequency': 323,
            'location': '',
            'mobilePhone': '',
            'name': '吉林百望科技发展有限公司',
            'province': '吉林省',
            'score': '15.748634323222657',
            'taxId': '91220101MA1460D915',
            'accLevel': '0',
            'taxAuthorityCode': '',
            'taxAuthorityName': ''
        }
    ]
}