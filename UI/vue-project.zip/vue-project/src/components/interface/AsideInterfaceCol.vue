<template>
<div>
    <el-row :gutter="10">
    <el-col :span="16"> <el-input autocomplete="off" placeholder="搜索测试集合" size="small"></el-input></el-col>
    <el-col :span="5"> <el-button type="primary" size="small">添加集合</el-button></el-col>
</el-row>
</div>
</template>

<script>
export default {

}
</script>

<style>
</style>
