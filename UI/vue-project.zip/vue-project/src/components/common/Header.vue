<template>
 <div class="header-box logo">
Header
  </div>

</template>

<script>
export default {

}
</script>

<style scope>
.header-box .logo{height:.56rem;line-height:.56rem}
</style>
