<template>
 <el-container>
    <my-banner></my-banner>
</el-container>
</template>

<script>
import myBanner from '../../components/common/MyBanner'
export default {
    name: 'projectIndex',
    components: {
    myBanner }

}
</script>

<style>

</style>
