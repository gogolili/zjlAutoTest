/**
 * Project Name:quality-service-integration
 * File Name:DemoUnitTest.java
 * Package Name:com.baiwang.cloud.integration
 * Date:2017年10月21日上午10:29:00
 * Copyright (c) 2017, wuyuegang@baiwang.com All Rights Reserved.
 *
*/

package com.baiwang.cloud.integration.test;
/**
 * 单元测试代码,如果不用,可以删除 <br/>
 * Date:     2017年10月21日 上午10:29:00 <br/>
 * @author   wuyuegang
 * @version  
 * @since    JDK 1.8
 * @see 	 
 */
public class DemoUnitTest
{
    
}

