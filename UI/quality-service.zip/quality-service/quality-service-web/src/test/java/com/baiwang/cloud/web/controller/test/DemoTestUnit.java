/**
 * Project Name:quality-service-web
 * File Name:DemoTestUnit.java
 * Package Name:com.baiwang.cloud.web.controller
 * Date:2017年10月21日上午10:27:24
 * Copyright (c) 2017, wuyuegang@baiwang.com All Rights Reserved.
 *
*/

package com.baiwang.cloud.web.controller.test;

/**
 * 单元测试代码,如果不用,可以删除 <br/>
 * Date: 2017年10月21日 上午10:27:24 <br/>
 * 
 * @author wuyuegang
 * @version
 * @since JDK 1.8
 * @see
 */
public class DemoTestUnit
{
    
}
