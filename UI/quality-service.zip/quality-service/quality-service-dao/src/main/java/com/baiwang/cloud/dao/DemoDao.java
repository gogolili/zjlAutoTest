package com.baiwang.cloud.dao;


/**
 * 模板测试接口，可以删除
 * 
 * @author wuyuegang
 * 
 */
public interface DemoDao
{
    /**
     * get quality-service list from db
     * 
     * @return
     */
    public String getProducts();
    
}
